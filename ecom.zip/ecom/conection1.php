<?php
$dsn = 'mysql:host=localhost;dbname=ecom';
$user = 'root';
$password = '';


/*
$db=new PDO($dsn,$user,$password);
$sql=$db->query("SELECT * FROM product");
while($row=$sql->fetch())
{
	echo"<pre>";
	print_r($row);
	echo"</pre>" ;
}

*/
try
{
	$db = new PDO($dsn,$user,$password);
	$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}
catch(PDOException $e)
{
	echo "PDO error".$e->getMessage();
	die();
}
?> 