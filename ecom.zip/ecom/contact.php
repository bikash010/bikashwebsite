<?php
require('top.php');
if(isset($_POST['submit']))
 {
    $name=get_sefe_value($con,$_POST['name']);
    $email=get_sefe_value($con,$_POST['email']);
    $mobile=get_sefe_value($con,$_POST['mobile']);
    $comment=get_sefe_value($con,$_POST['comment']);
    $add_on=date('Y-m-d h:i:s');

     mysqli_query($con,"INSERT INTO contact_us (name,email,mobile,comment,add_on) Values('$name','$email','$mobile','$comment','$add_on')");


}        


?>
<div class="inf" style="margin-left:50px;background-color:ghostwhite;width:1450px;">
    <h2 class="cont"> CONTACT US </h2>
            <dvi class="contact">
                
                <div class="admininfo">
                    <p>Tel-phone:010520585</p>
                    <p>Mobile: 9841063130</p>
                    <p>Fax-no:256482</p>
                </div>
                <div class="info">
                    <p>Gmail:<a href="#">trimurtimobilehouse@gmail.com</a></p>
                    <div>For more information:visit us
                        <p>address:bichbazar,dhadingbensi,nepal</p>
                    </div>
                </dvi> 
            </div>
</div>
<hr style="margin-left:50px;width:1400px;">
<p style="margin-left:50px;width:1400px;background-color:ghostwhite;padding-left:50px;font-size:20px;">feedback</p>
<hr style="margin-left:50px;width:1400px;">
<div class="smail" style="margin-left:50px;background-color:ghostwhite;width:1350px;">
    <p>send mail</p>
    <form method="post">
        
        <label>Name</label>
            <input type="text"  name="name"  placeholder="enter your name" class="mail" required>

        <label>Email</label>
            <input type="email"  name="email"  placeholder="enter your email" class="mail" required>

        
            <label>Number</label>
            <input type="number"  name="mobile"  placeholder="enter your number" class="mail" required>
        
        
            <label>problem</label>
            <textarea  name="comment"  placeholder="enter your Inquery"  rows="24" cols="24" class="comment"></textarea>

            <button type="submit" name="submit" class="bnt"> send massege</button>
    </form> 
</div>