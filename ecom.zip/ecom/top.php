<?php
require('connection.inc.php');
require('function.inc.php');
$cat_id='';

if(isset($_GET['id']) && $_GET['id']!='')
{
    $cat_id=get_sefe_value($con,$_GET['id']);
}

?>
<html>
    <head><title>online shoping </title>
        <link rel="stylesheet" type="text/css" href="style.css">
        <link rel="stylesheet" type="text/css" href="login.css">
        <link rel="stylesheet" type="text/css" href="checkout.css">
        <style type="text/css">
        }
.fonted .hori ul li {
    position:relative;
    text-decoration: none;
    font-size:18px;
    padding-left:0px;
    font-weight: 500;
    display:block;
    width:100%;
    border-left:3px solid transparent;
}
.dropdown
{
      display:none;
}
.fonted .hori ul li:hover .dropdown
{
    position:absolute;
    display:block;
    
}
        </style>
        
        
        
        
    </head>
<body>
  <div class="fonted" style="margin-left:50px;width:1450px;">
        <div class="image">
        <img src="logo.jpg" style="border-radius:50%;">
        </div>
        <div class="hori">
            <ul>
                    <li class="home"><a href="index.php">home</a></li>
                        <?php
                                $cat_res=mysqli_query($con,"SELECT * from categories where status=1 order by categories asc");

                                while($row=mysqli_fetch_assoc($cat_res)){?>
                                    <li class="drop"><a href="categories.php?id=<?php echo $row['id']?>"><?php echo $row['categories']?></a>
                                        <?php
                                            $sub_cat_res=mysqli_query($con,"SELECT * from subcategories where 
                                            ( status='1' and categories_id='$cat_id' )");
                                            
                                    
                                                if(mysqli_num_rows($sub_cat_res)>0){
                                        ?>
                                                <ul class="dropdown">
                                                    <?php 
                                                    while($sub_cat_rows=mysqli_fetch_assoc($sub_cat_res)){?>
    
                                                        <li><a href="categories.php?id=<?php echo $sub_cat_rows['categories_id'].
                                                            '&sub_categories='. $sub_cat_rows['id'] ?> ">
                                                            <?php echo $sub_cat_rows['subcategories'].'&nbsp&nbsp&nbsp'?></a></li>
   
                                                   <?php }
                                                    ?>
                                                </ul>
                                                                                <?php } ?>              
                    
                                    </li>
                                
                        <?php } ?>

                        <li><a href="contact.php">contact</a></li>
            </ul>
        </div>

        <div class="login">
        
            <?php if(isset($_SESSION['USER_LOGIN']))
            {
                echo 'Welcome'.' '.$_SESSION['USER_NAME'].' '. '<a href="logout.php">Lougout</a>'.'|'.'<a href="myorder.php" style="color:red;">my order</a>';
            }
            else {
                echo '<a href="login.php">login/registration</a>';
            }
            ?>
    
                <a href="cart.php"> <img src="addcart.jpg" style="width:30px; height:30px;"><span style="border:1px solid red;margin-left:25px;border-radius:50%;color:white;background-color:red;"><?php 
                        echo (isset($_SESSION['cart_items']) && count($_SESSION['cart_items'])) > 0 ? count($_SESSION['cart_items']):'';
                        
                    ?></span>
                
                </a>
            </div>
           
    </div>

