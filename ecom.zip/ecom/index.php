<?php
require('top.php');
?>
    <div style="background-color:ghostwhite;margin-left:50px;width:1450px;">
        <form action="search.php" method="get">
            <div class="info">
                <input  placeholder="search here......." type="text" name="str" class="inp" style=" padding-left:200px;margin-bottom:5px; margin-left:400px;width:600px;height:50px;"><button type="submit" ></button></input>
                
            </div>
            
        </form>
        
    </div>
        <div class=new style="margin-left:50px;width:1450px;">
                <h2 class="title">New Arrivals</h2>
                <p>But I must explain to you how all this mistaken idea</p>
        </div>
        <div class="rol" style="margin-left:50px;width:1250px;">
                <?php
                    $get_product=get_product($con,5);
                    foreach($get_product as $list){ 
                     ?>
                        <div class="newar"> 
                                <div class="category" style="height:381px;">
                                    <div>
                                        <a href="product.php?id=<?php echo $list['id']?>">
                                            <img src="<?php echo  PRODUCT_IMAGE_SITE_PATH.$list['image']?>">
                                        </a>
                                        
                                    </div>
                                    <div class="prodcutd">
                                    <h4><a  href="#"><?php echo 'Name:'.$list['name']?></a></h4>
                                    <ul class="price">
                                        <li class="oldp"><?php echo 'MRP:'.$list['mrp']?></li>
                                        <li><?php echo 'Price:'.$list['price']?></li>
                                    </ul>
                                    </div>
                                </div>
                        </div>
                 <?php } ?>
         </div> 
         <div class=new style="margin-left:50px;width:1450px;">
                <h2 class="title">Best seller product</h2>
                
        </div>
        <div class="rol" style="margin-left:50px;width:1250px;">
                <?php
                    $get_product=get_product($con,5,'','','','','yes');
                    foreach($get_product as $list){ 
                     ?>
                        <div class="newar"> 
                                <div class="category" style="height:381px;">
                                    <div>
                                        <a href="product.php?id=<?php echo $list['id']?>">
                                            <img src="<?php echo  PRODUCT_IMAGE_SITE_PATH.$list['image']?>">
                                        </a>
                                        
                                    </div>
                                    <div class="prodcutd">
                                    <h4><a  href="#"><?php echo 'Name:'.$list['name']?></a></h4>
                                    <ul class="price">
                                        <li class="oldp"><?php echo 'MRP:'.$list['mrp']?></li>
                                        <li><?php echo 'Price:'.$list['price']?></li>
                                    </ul>
                                    </div>
                                </div>
                        </div>
                 <?php } ?>
         </div>          
</body>
</html>