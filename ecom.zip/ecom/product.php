<?php
require('top.php');
require('conection1.php');
$product_id=mysqli_real_escape_string($con,$_GET['id']);
$get_product=get_product($con,'','',$product_id);

if(isset($_GET['id']) && !empty($_GET['id']) && is_numeric($_GET['id']))
{
    $sql = "SELECT  * from product  WHERE  id =:productID";
    $handle = $db->prepare($sql);
    $params = [
        ':productID' =>$_GET['id'],
    ];
    $handle->execute($params);
        if($handle->rowCount() == 1 )
        {
            $getProductData = $handle->fetch(PDO::FETCH_ASSOC);
        }
        else
        {
            $error = '404! No record found';
        }
 
    }
    else
    {
        $error = '404! No record found';
    }

    if(isset($_POST['add_to_cart']) && $_POST['add_to_cart'] == 'add to cart')
    {
        $productID = intval($_POST['product_id']);
        $productQty = intval($_POST['product_qty']);
        
        $sql = "SELECT  * from product  WHERE  id =:productID";
        $prepare = $db->prepare($sql);
        
        $params = [
    
                ':productID' =>$productID,
            ];

        $handle->execute();
        $fetchProduct = $handle->fetch(PDO::FETCH_ASSOC);
        
    
        $calculateTotalPrice = number_format($productQty * $fetchProduct['price'],2);
        
        $cartArray = [
            'product_id' =>$productID,
            'qty' => $productQty,
            'product_name' =>$fetchProduct['name'],
            'product_price' => $fetchProduct['price'],
            'total_price' => $calculateTotalPrice
        ];
          
       
        
        if(isset($_SESSION['cart_items']) && !empty($_SESSION['cart_items']))
        {
            $productIDs = [];
            foreach($_SESSION['cart_items'] as $cartKey => $cartItem)
            {
                $productIDs[] = $cartItem['product_id'];
                if($cartItem['product_id'] == $productID)
                {
                    $_SESSION['cart_items'][$cartKey]['qty'] = $productQty;
                    $_SESSION['cart_items'][$cartKey]['total_price'] = $calculateTotalPrice;
                    break;
                }
            }
    
            if(!in_array($productID,$productIDs))
            {
                $_SESSION['cart_items'][]= $cartArray;
                
            }
    
            $successMsg = true;
            
        }
        else
        {
            $_SESSION['cart_items'][]= $cartArray;
            $successMsg = true;
        }
    
    }
    
    
?> 
<div class="banner" style="margin-left:50px;width:1450px;background-color:ghostwhite;">
        <div class="image">
        <img src="online1.jpg" alt="trimurti1.jpg">
        </div>
        <div class="hori">
           <li><a class="home1" href="index.php">home</a></li>
           <span>></span>
           <a href="categories.php>id=<?php echo $get_product['0']['categories_id']?>"><?php echo $get_product['0']['categories']?></a>
           <span>></span>
          <li> <a href='#'><?php echo $get_product['0']['name']?></a></li>
       </div>
</div> 



<?php if(isset($getProductData) && is_array($getProductData)){?>
        <?php if(isset($successMsg) && $successMsg == true){?>

                    <div style="margin-left:50px;width:1450px;background-color:ghostwhite;color:green;">
                        
                        <?php echo $getProductData['name']?> is added to cart. <a href="cart.php" style="color:green;">View Cart</a>
                        <button type="button" class="close" ></button>
                    </div>
           
         <?php }?>

<div id="product-grid" style="margin-left:50px;width:1450px;background-color:ghostwhite;">
    <div class="product-item">
        
                 <div class="newar" >

                        <div class="category">
                            <a hrerf="#">
                                <img src="<?php echo PRODUCT_IMAGE_SITE_PATH.$get_product['0']['image']?>">
                             </a>  
                         </div>           
                                <div class="prodcutd">
                                    <h4><?php echo "Product Name:".$get_product['0']['name']?></h4>
                                        <ul class="price">
                                            <li class="oldp"><?php echo "MRP:".$get_product['0']['mrp']?></li>
                                            <li><?php echo "Price:".$get_product['0']['price']?></li>
                                        </ul>
                                             <p class="description"><?php echo "Description:".$get_product['0']['short_desc']?></p>
                                                <div class="stock">
                                                    <div class="shortd">
                                                        <p><span>availability:</span>on stock</p>
                                                    </div>
                                </div>
                                        <div class="cat">
                                            <ul class="fashion">
                                                <li><?php echo "Category:". $get_product['0']['categories'] ?></li>
                                                    <div class="cart-action">
                                            
                                                            <form class="form-inline" method="POST">
                                                                <div>
                                                                   Qty:<input type="number" name="product_qty" id="productQty" class="for m-control" placeholder="Quantity" min="1" max="1000" value="1">
                                                                    <input type="hidden" name="product_id" value="<?php echo $get_product['0']['id']?>">
                                                                </div>
                                                                <div>
                                                                    <button type="submit" class="btn" name="add_to_cart" value="add to cart">Add to Cart</button>
                                                                </div>
                                                            </form>
                
                                                    </div>
                                            </ul>
                                        </div>
                                            
                                        
                                
                                            
                </div>
                           

	</div>
	
</div>
<div class="ldescription"><h4>long description</h4>
                                <p><?php echo "Description:".$get_product['0']['description']?></p>
</div>
<?php
    }
    ?>