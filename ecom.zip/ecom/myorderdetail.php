<?php 
    require('top.php');
    require('conection1.php'); 
    $order_id='';
    if(isset($_GET['id']) )
    {
        $order_id=$_GET['id'];
       
    }

?>

<div class="banner" style="margin-left:50px;background-color:ghostwhite;width:1450px;">
        <div class="image">
        <img src="online1.jpg" alt="trimurti1.jpg" id="slideimage">
        </div>
        <div class="hori">
           <li><a class="home1" href="index.php">home</a></li>
           <span>></span>
          <li> <a href='myorder.php'>my order</a></li>
          <span>></span>
          <li> <a href='#'> order details</a></li>
       </div>
</div>




<div class="row" style="margin-left:50px;background-color:ghostwhite;width:1450px;">
        <table>
        
           <thead>
                <tr>
                    <th style="text-align:cemter;" width="300px" height="5px">product Name</th>
                    <th style="text-align:cemter;" width="300px" height="5px">Qty</th>
                    <th style="text-align:cemter;" width="300px" height="5px">price</th>
                    <th style="text-align:cemter;" width="300px" height="5px">total price</th>
                    
                
                </tr>
            </thead>
            <tbody>
                <?php
                  $uid=$_SESSION['USER_ID']; 
                  $total_price=0;
                  $itemCounter =0;
                  $res=mysqli_query($con,"SELECT distinct(order_detail.id), order_detail.* from order_detail,orders
                   where order_detail.order_id='$order_id' and orders.user_id='$uid' ");
            
              while($row=mysqli_fetch_assoc($res)){
                $total_price=$total_price+($row['qty']*$row['product_price']);
                $itemCounter+=$row['qty'];
                ?>
                <tr >
                        
                        <td style="padding-left:40px;">
                            <?php echo $row['product_name'];?>
                        </td>
                        
                        
                        <td style="padding-left:40px;">
                            <?php echo $row['qty'];?>
                        </td>
                        <td style="padding-left:40px;">
                            <?php echo $row['product_price'];?>
                        </td>
                        <td style="padding-left:40px;">
                            <?php echo $row['qty']*$row['product_price'];?>
                        </td>
                        
                        
                    </tr>
                <?php } ?>
                <tr class="border-top border-bottom">
                    <td style="padding-left:300px;">Total</td>
                    <td style="padding-left:70px; ">Total items:
                        <strong>
                            <?php 
                                echo ($itemCounter==1)?$itemCounter.' item':$itemCounter.' items'; ?>
                        </strong>
                    </td>
                    <td style="padding-left:240px;" colspan="2"><strong>Total :Rs<?php echo $total_price;?></strong></td>
                </tr>
 </tbody>
        
        </table>
</div>
          
