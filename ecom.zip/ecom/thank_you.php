<?php
require('top.php');
require('conection1.php');
?>
<div class="banner">
        <div class="image">
        <img src="trimurti1.jpg" alt="trimurti1.jpg" id="slideimage">
        </div>
        <div class="hori">
           <li><a class="home1" href="index.php">home</a></li>
           <span>></span>
          <li> <a href='#'>thank you </a></li>
       </div>
</div>
<script>
        var image=["trimurti1.jpg","trimurti2.jpg","shop.jpg"];
        var i=0;
        function slides(){
        document.getElementById("slideimage").src=image[i];
        if(i<(image.length-1))
        i++;
        else 
        i=0;
    }
    setInterval(slides,1000);
</script>
<p>Your order has been placed successfully. </p>
