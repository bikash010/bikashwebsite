<?php 
    require('top.php');
    require('conection1.php'); 

    if(isset($_GET['action'],$_GET['item']) && $_GET['action'] == 'remove')
    {
        unset($_SESSION['cart_items'][$_GET['item']]);
        header('location:cart.php');
        exit();
    }


?>
<div class="banner" style="margin-left:50px;background-color:ghostwhite;width:1450px;">
        <div class="image">
        <img src="online1.jpg" alt="trimurti1.jpg" id="slideimage">
        </div>
        <div class="hori">
           <li><a class="home1" href="index.php">home</a></li>
           <span>></span>
          <li> <a href='#'>cart</a></li>
       </div>
</div>
<div class="row" style="background-color:ghostwhite;">
    <div >
        <?php if(empty($_SESSION['cart_items'])){?>
        <table class="table" style="margin-left:50px;">
            <tr>
                <td>
                    <p style="margin-left:50px;background-color:ghostwhite;">Your cart is emty</p>
                </td>
            </tr>
        </table>
        <?php }?>
        <?php if(isset($_SESSION['cart_items']) && count($_SESSION['cart_items']) > 0){
            ?>
        <table class="table" style="margin-left:50px;background-color:ghostwhite;width:1450px;" >
           <thead>
                <tr>
                    <th style="text-align:cemter;" width="300px" height="5px">Product</th>
                    <th style="text-align:cemter;" width="300px" height="5px">Price</th>
                    <th style="text-align:cemter;" width="300px" height="5px">Qty</th>
                    <th style="text-align:cemter;" width="300px" height="5px">Total</th>
                    <th style="text-align:cemter;" width="100px" height="5px"> </th>
                </tr>
            </thead>
            <tbody>
                <?php 
                    $totalCounter = 0;
                    $itemCounter = 0;
                    foreach($_SESSION['cart_items'] as $key => $item){ 
                    
                    $total = $item['product_price'] * $item['qty'];
                    $totalCounter+= $total;
                    $itemCounter+=$item['qty'];
                    ?>
                    <tr >
                        <td style="padding-left:120px;">
                            <?php echo $item['product_name'];?>

                        </td>
                        <td style="padding-left:120px;">
                            Rs<?php echo $item['product_price'];?>
                        </td>
                        <td style="padding-left:120px;">
                            <input type="number" name="" data-item-id="<?php echo $key?>" value="<?php echo $item['qty'];?>" min="1" max="1000" >
                        </td>
                        <td style="padding-left:120px;">
                            <?php echo $total;?>
                        </td>

                        <td style="text-align:center;"><a href="cart.php?action=remove&item=<?php echo $key?>">delete</a></td>
                    </tr>
                <?php }?>
                <tr class="border-top border-bottom">
                    <td style="padding-left:300px;" colspan="2">Total</td>
                    <td style="padding-left:70px; ">Total items:
                        <strong>
                            <?php 
                                echo ($itemCounter==1)?$itemCounter.' item':$itemCounter.' items'; ?>
                        </strong>
                    </td>
                    <td style="padding-left:120px;"><strong>Rs<?php echo $totalCounter;?></strong></td>
                </tr> 
                </tr>
            </tbody> 
        </table>
        <div class="row">
            <div>
                <a href="index.php" style="padding-left:40px;border:1px solid red;margin-left:60px;background-color:red;">continue shopping</a>
				<a href="checkout.php">
					<button class="bnt" style="margin-left:1000px;background-color:red;">Checkout</button>
				</a>
            </div>
        </div>
        
        <?php }?>
    </div>
</div>
