<?php
require('top.php');
require('conection1.php');
$cartItemCount = count($_SESSION['cart_items']); 
if(isset($_GET['action'],$_GET['item']) && $_GET['action'] == 'remove')
{
    unset($_SESSION['cart_items'][$_GET['item']]);
    header('location:checkout.php');
    exit();
}
$mobile='';
$fname='';
$mname='';
$lname='';
$password='';
$compassword='';
$email='';
$gen='';
$address1='';
$address2='';
$street_add='';
$city='';
$pin_code='';
$product_id='';
$order_id='';
$qty='';
$product_price='';
$product_name='';

if (isset($_POST["resister"])) {

    $number =get_sefe_value($con,$_POST["number"]); 
    $fname=get_sefe_value($con,$_POST["fname"]); 
    $mname =get_sefe_value($con,$_POST["mname"]);
    $lname =get_sefe_value($con,$_POST["lname"]);
    $password =get_sefe_value($con,$_POST["password"]); 
    $compassword =get_sefe_value($con,$_POST["compassword"]); 
    $email =get_sefe_value($con,$_POST["email"]); 
    $gender =get_sefe_value($con,$_POST["gen"]); 
    $address1 =get_sefe_value($con,$_POST["address1"]);
    $address2 =get_sefe_value($con,$_POST["address2"]); 
    $add_on=date('Y-m-d h:i:s');
    
        mysqli_query($con,"INSERT INTO users(number,fname,mname,lname,password,email,gender,address1,address2,add_on) Values('$number','$fname','$mname','$lname','$password','$email','$gender','$address1','$address2','$add_on')");
}
if(isset($_POST['submit']))
  {
      $number=get_sefe_value($con,$_POST['number']);
      $password=get_sefe_value($con,$_POST['password']);
      $sql="select *from users where number='$number' and password='$password' ";
      $res=mysqli_query($con,$sql);
      $count=mysqli_num_rows($res);
      if($count>0)
      {
        $row=mysqli_fetch_assoc($res);
         $_SESSION['USER_LOGIN']='yes';
         $_SESSION['USER_ID']=$row['id'];
         $_SESSION['USER_NAME']=$row['fname'];
        }
      else
      {
          echo "wrong";
      }
  }

$totalCounter = 0;
$itemCounter = 0;
  if(isset($_POST['submit1']))
 {
    $street_add=get_sefe_value($con,$_POST['street_add']);
    $city=get_sefe_value($con,$_POST['city']);
    $pin_code=get_sefe_value($con,$_POST['pin_code']);  
    $payment_type=get_sefe_value($con,$_POST['payment_type']); 
    $user_id=$_SESSION['USER_ID'] ;
    foreach($_SESSION['cart_items'] as $key => $item){ 
                    
        $total = $item['product_price'] * $item['qty'];
        $totalCounter+= $total;
        $itemCounter+=$item['qty'];
 }
 $tatal_price=$totalCounter;
 $payment_status='success';
 if($payment_type=='COD')
 {
     $payment_status='pending';
 }
 $order_status='1';
 $add_on=date('Y-m-d h:i:s');
 mysqli_query($con,"INSERT INTO orderS(user_id,street_add,city,pin_code,payment_type,payment_status,tatal_price,order_status,add_on) VALUES('$user_id','$street_add','$city','$pin_code','$payment_type','$payment_status','$tatal_price','$order_status','$add_on')");

 $order_id=mysqli_insert_id($con);
 foreach($_SESSION['cart_items'] as $key =>$cartItem)
 {
    
    $product_name=$cartItem['product_name'];
    $qty=$cartItem['qty'];
    $product_price=$cartItem['product_price'];
     $total = $cartItem['product_price'] * $cartItem['qty'];
     $totalCounter+= $total;
    mysqli_query($con,"INSERT into order_detail(order_id,product_name,qty,product_price) VALUES('$order_id','$product_name','$qty','$product_price')");
    
}
unset($_SESSION['cart_items']);
    ?>
    <script>
        window.location.href="thank_you.php";
    </script>
    <?php 
}

?>
<div class="banner" style="margin-left:50px;background-color:ghostwhite;width:1450px;">
        <div class="image">
        <img src="online1.jpg" id="slideimage">
        </div>
        <div class="hori">
           <li><a class="home1" href="index.php">home</a></li>
           <span>></span>
          <li> <a href='cart.php'>cart</a></li>
          <span>></span>
          <li>checkout</li>
       </div>
</div>

<div  class="checkout" style="margin-left:50px;background-color:ghostwhite;width:1450px;">
    <hr><hr>
    <div class="infocheck">
                
        <h1  class="head">Your cart</h1>
            <a href="cart.php"> <img src="addcart.jpg" style=" margin-left:10px;width:30px; height:30px;"><span><?php echo $cartItemCount;?></span>
            <ul  class="list" >
                <h1 style="text-decoration:none;size:12px;">Your total order </h1>
                    <?php
                        $totalCounter = 0;
                        foreach($_SESSION['cart_items'] as $key =>$cartItem)
                        {
                            $total = $cartItem['product_price'] * $cartItem['qty'];
                            $totalCounter+= $total;
                        ?>
                            <li style="border-bottom:1px solid blue; margin:40px;list-style:none;">
                                <div>
                                
                                    <h6 >Product Name:<?php echo $cartItem['product_name'] ?></h6>
                                    <small>Quantity: <?php echo $cartItem['qty'] ?> * Price: <?php echo $cartItem['product_price'] ?></small>
                                    <a style="border:1px solid red; background-color:red;" href="checkout.php?action=remove&item=<?php echo $key?>">delete</a>
                                </div>
                                    <span class="text-muted">price :Rs<?php echo $cartItem['total_price'] ?></span>
                            </li>
                    <?php
                        }
                    ?>
                
                <li style="list-style:none;">
                    <span>Total product price (Rs)</span>
                        <strong>Rs<?php  echo $totalCounter;?></strong>
                </li>
            </ul>
    </div>
    <?php if(isset($_SESSION['USER_LOGIN'])){
                        ?> 
    <div class="payment"> 
        
        <form method="post">
        <p>address information</p>
        <input type="text" name="street_add" class="street_add" placeholder=" Enter street Aaddress" required>
        <input type="text" name="city" class="city" placeholder=" city/state" required>
        <input type="number" style="height:40px; width:280px;" name="pin_code" class="pin_code" placeholder=" Enter post code" required><br>
        <p>payment information</p>
        COD:<input type="radio" name="payment_type"  value="COD">
        payU:<input type="radio" name="payment_type" value="payU"> <br><br>                       
        <button type="submit" name="submit1" class="submit1"> click submit</button><br>
                                
                
         </form>

      </div> 
      <?php }  ?>

    <?php if(!isset($_SESSION['USER_LOGIN'])){
                        ?> 
    <div class="login1">
                    
                    
                    <h2 class="header">login<h2>
                            <form method="post" onsubmit="return validlogin()">
                                    <p> <label>username</label></p>
                                    <input type="text" name="number" id="number23" class="info" placeholder=" Enter number">
                                    <span  id="numbeer1" style="
                                                   font-size:20px;
                                                       color:red;
                                                      "></span>
                                <p> <label>password</label></p>
                                    <input type="password" name="password" id="paassword23" class="info" placeholder=" Enter password"><br>
                                    <span class="field_error" id="passwoord1" style="
                                                                 font-size:20px;
                                                                  color:red;
                                                                  "></span>
                                    <button type="submit" name="submit" class="bnt"> login</button><br>
                                
                                
                            </form>
     </div>
       
       <div class="registration1">
            <h2 class="regi">registration<h2>
                <form method="post" onsubmit="return validation()" >

                <div class="input-group">
                        <label>Mobile*</label>
                        <select class="selected">
                            <option>+977</option>
                            <option>+81</option>
                            <option>+29</option>
                            <option>+83</option>
                            <option>+79</option>
                        </select><input type="number" name="number" id="number" placeholder="mobile number" class="mobile">
                        <span class="field_error" id="number1" style="
                            font-size:20px;
                            color:red;
                        "></span>
                    </div>
            
            
                    <div class="input-group">
                        <label>First Name*</label>
                        <input type="text" name="fname" placeholder="first name" class="fname" id="fname">
                        <span id="firname"   style="
                            font-size:20px;
                            color:red;"></span>
                    </div>
                    <div class="input-group">
                        <label>middle Name</label>
                        <input type="text" name="mname" placeholder="middle name" class="mname">
                        <span class="field_error" id="name_error" style="
                            font-size:20px;
                            color:red;
                        "></span>
                    <div>
                    <div class="input-group">
                        <label>last Name*</label>
                        <input type="text" name="lname" placeholder="last name" class="lname" id="lname" >
                        <span id="lname1" style="
                            font-size:20px;
                            color:red;
                        "></span>
                    <div>
                    <div class="input-group">
                        <label>password*:</label>
                        <input type="password" name="password" placeholder="password" class="password" class="password"  id="password">
                        <span class="field_error" id="password1" style="
                            font-size:20px;
                            color:red;
                        "></span>
                    </div>
                    <div class="input-group">
                        <label>comfirm password*:</label>
                        <input type="password" name="compassword" placeholder="comfirm password" class="conp" id="compassword">
                        <span class="field_error" id="compassword1" style="
                            font-size:20px;
                            color:red;
                        "></span>
                    </div>
                    <div class="input-group">

                        <label>Email*:</label>
                        <input type="text" name="email" placeholder="Email" class="email" id="email">
                        <span class="field_error" id="email1" style="
                            font-size:20px;
                            color:red;
                        "></span>
                    </div>
                    <div class="input-group">
                        <label>Gender*:</label> <p style="font-size:25px;display:inline;"> Male:</P> 
                        <input type="radio" name="gen" value="male" > 
                        <p style="font-size:25px;
                        display:inline;">Female:</P>
                        <input type="radio" name="gen" value="female">
                    </div>
                    <div class="input-group">
                        <label>Permanent address*:</label><input type="text" name="address1" id="address1" placeholder="permanent address" class="paddress">
                        <span class="field_error" id="adddress1" style="
                            font-size:20px;
                            color:red;
                        "></span> 
                    </div>
                    <div class="input-group">
                        <label>Temporary address*:</label><input type="text" name="address2" id="address2" placeholder="Temporary address" class="taddress"> 
                        <span class="field_error" id="adddress2" style="
                            font-size:20px;
                            color:red;
                        "></span>
                    </div>
                <div class="input-group">
                <button type="submit" name="resister" class="bnt"> Resister</button>
                </div>
                <p>
                    <a href="#">Already a member?</a><a href="login.php">sign in </a>
                </p>
                 
                </form>

        </div>
     <?php }  ?>
    

</div>
<script>
function validation()
{
    
   var number= document.getElementById('number').value;
   var fname= document.getElementById('fname').value;
   var lname= document.getElementById('lname').value;
   var password= document.getElementById('password').value;
   var compassword= document.getElementById('compassword').value;
   var email= document.getElementById('email').value;
   var address1= document.getElementById('address1').value;
   var address2= document.getElementById('address2').value;
     if(number=='')
   {
       document.getElementById('number1').innerHTML="** please the fill the number field..";
       return false;
   }
   if(isNaN(number))
   {
       document.getElementById('number1').innerHTML="** only number not character..";
       return false;
   }
   if(number.length !=10)
   {
       document.getElementById('number1').innerHTML="** mobile number must be 10 digit only.";
       return false;
   }
   if(fname=='')
   {
       document.getElementById('firname').innerHTML="** please the fill the first name field..";
       return false;
   }
   if(lname=='')
   {
       document.getElementById('lname1').innerHTML="** please the fill the last name field..";
       return false;
   }
   if(password=='')
   {
       document.getElementById('password1').innerHTML="** please the fill the password  field..";
       return false;
   }
   if(isNaN(password))
   {
       document.getElementById('number1').innerHTML="** only number not character..";
       return false;
   }
   if((password.length <=5) || (password.length >10))
   {
       document.getElementById('password1').innerHTML="** password lenth must be between 5 and 10..";
       return false;
   }
   if(password !=compassword )
   {
       document.getElementById('password1').innerHTML="** password are not matching";
       return false;
   }
   if(compassword=='')
   {
       document.getElementById('compassword1').innerHTML="** please the fill the password  field..";
       return false;
   }
   if(email=='')
   {
       document.getElementById('email1').innerHTML="** please the fill the email field.";
       return false;
   }
   if(email.indexOf('@')<=0)
   {
       document.getElementById('email1').innerHTML="**@  invalid position in email..";
       return false;
   }
   if((email.charAt(email.length-4)!='.') && (email.charAt(email.length-3)!='.'))
   {
       document.getElementById('email1').innerHTML="** . invalid position in  email ..";
       return false;
   }
   if(address1=='')
   {
       document.getElementById('adddress1').innerHTML="** please the fill the permanent address field..";
       return false;
   }
   if(address2=='')
   {
       document.getElementById('adddress2').innerHTML="** please the fill the temporary address field..";
       return false;
   }
   

}
function validlogin()
    {
                    var number= document.getElementById('number23').value;
                    var password= document.getElementById('paassword23').value;
                    if(number=='')
            {
                document.getElementById('numbeer1').innerHTML="** please the fill the number field..";
                return false;
            }
                    if(number.length !=10)
            {
                document.getElementById('numbeer1').innerHTML="** mobile number must be 10 digit only.";
                return false;
            }  
            if(password=='')
             {
                document.getElementById('passwoord1').innerHTML="** please the fill the password  field..";
                 return false;
               }
                if((password.length <=5) || (password.length >10))
                {
                    document.getElementById('passwoord1').innerHTML="** password lenth must be between 5 and 10..";
                    return false;
                }
    }
</script>