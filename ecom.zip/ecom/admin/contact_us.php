<?php

require('top.inc.php');
if(isset($_GET['type']) && $_GET['type']!='')
{
    $type=get_sefe_value($con,$_GET['type']);
    

    if($type=='delete')
    {
        $id=get_sefe_value($con,$_GET['id']);
        
        $delete_status="delete from  contact_us where id='$id'";
        mysqli_query($con,$delete_status);
    }
}
$sql="select * from  contact_us order by id desc";
$res=mysqli_query($con,$sql);
?>

                                                                            
                       <div class="body">
                           <div class="order">
                               <h2 class="add">Message</h2>
                            </div>
                            
                                <table>
                                    <thead>
                                        <tr>
                                            <th>id</th>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>mobile</th>
                                            <th>Inquery</th>
                                            <th>date</th>
                                            <th></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php 
                                        while($row=mysqli_fetch_assoc($res)) {?>
                                        <tr>
                                            <td><?php echo $row['id'] ?></td>
                                            <td><?php echo $row['name'] ?></td>
                                            <td><?php echo $row['email'] ?></td>
                                            <td><?php echo $row['mobile'] ?></td>
                                            <td><?php echo $row['comment'] ?></td>
                                            <td><?php echo $row['add_on'] ?></td>
                                            <td>
                                                <?php
                                                 
                                                echo "<span class='dele'> <a href='?type=delete&id=".$row['id']." '>delete </a></span>&nbsp";
                                                
                                                ?>
                                            </td>
                                        </tr>
                                        <?php } ?>
                                     </tbody>

                                </table>


<?php
require('footer.inc.php')
?>