<div class="foot">
                                        <div>
                                            <p>copyright &copy:<?php echo date('Y') ?> bikash</p>
                                        </div>
                                    </div>
                            
                        </div>
                    </div>
                
            </div>      

        
</body>