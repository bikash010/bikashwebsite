<?php

require('top.inc.php');
$sql="select * from orders order by id desc";
$res=mysqli_query($con,$sql);
?>

                                                                            
                       <div class="body">
                           <div class="order">
                               <h2 class="add">orders</h2>
                            </div>
                            
                                <table>
                                    <thead>
                                        <tr>
                                            <th>id</th>
                                            <th>user_id</th>
                                            <th>street_add</th>
                                            <th>city</th>
                                            <th>pin_code</th>
                                            <th>payment_type</th>
                                            <th>payment_status</th>
                                            <th>tatal_price</th>
                                            <th>order_status</th>
                                            <th>add_on</th>
                                            <th></th>
                                            
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php 
                                        while($row=mysqli_fetch_assoc($res)) {?>
                                        <tr>
                                            <td><?php echo $row['id'] ?></td>
                                            <td><?php echo $row['user_id'] ?></td>
                                            <td><?php echo $row['street_add'] ?></td>
                                            <td><?php echo $row['city'] ?></td>
                                            <td><?php echo $row['pin_code'] ?></td>
                                            <td><?php echo $row['payment_type'] ?></td>
                                            <td><?php echo $row['payment_status'] ?></td>
                                            <td><?php echo $row['tatal_price'] ?></td>
                                            <td><?php echo $row['order_status'] ?></td>
                                            <td><?php echo $row['add_on'] ?></td>
                                            
                                        </tr>
                                        <?php } ?>
                                     </tbody>

                                </table>


<?php
require('footer.inc.php')
?>