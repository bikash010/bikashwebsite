<?php
 require('connection.inc.php');
 require('function.inc.php');
 
?>
<html>
    <meta charset="utf-8">
    <head><title>siderbar dashbord</title>
        <link rel="stylesheet" href="style.css">
    </head>
<body>
    <div class="navi">
        <ul class="hori">
            <li>
                <div class="image">
                <image class="image" src="logo.jpg" style="border-radius:50%;"> </image> 
            </div>
            </li>
            <li class="h1"><a href="#">welcome admin</a>
                <div class="log">
                    <ul>
                        <a href="logout.php">logout</a>
                    </ul>
                </div>
        </ul>
    </div>

    <div class="side-bar">
                        <div class="menu">
                            <p>menu</p>
                            <ul class="first">
                                <li class="m1"><a href="categories.php">Categories Master</a></li>
                                <li class="m1"><a href="subcategories.php">Sub Categories Master</a></li>
                                <li class="m1"><a href="product.php">product master</a></li>
                                <li class="m1"><a href="ordermaster.php">order master</a></li>
                                <li class="m1"><a href="users.php">user master</a></li>
                                <li class="m1"><a href="contact_us.php">Message </a></li>

                            </ul>

                        </div>
                                                                
