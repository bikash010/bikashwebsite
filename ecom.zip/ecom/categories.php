<?php
require('top.php');
$cat_id=mysqli_real_escape_string($con,$_GET['id']);

$id='';

if(isset($_GET['id']) && $_GET['id']!='')
{
    $id=get_sefe_value($con,$_GET['id']);
}
$sub_categories='';
if(isset($_GET['sub_categories']) && $_GET['sub_categories']!='')
{
    $sub_categories=get_sefe_value($con,$_GET['sub_categories']);
}
$get_product=get_product($con,'',$cat_id,'','',$sub_categories);
?>
<div style="margin-left:50px;background-color:ghostwhite;width:1450px;">
        <form action="search.php" method="get" >
            <div class="info">
                <input  placeholder="search here......." type="text" name="str" class="inp" style=" padding-left:200px;margin-bottom:5px; margin-left:400px;width:600px;height:50px;"><button type="submit" ></button></input>
                
            </div>
            
        </form>
        
 </div>
<div class="banner" style="margin-left:50px;background-color:ghostwhite;width:1450px;">
        <div class="image">
        <img src="online1.jpg" alt="trimurti2.jpg" id="slideimage">
        </div>
        <div class="hori">
           <li><a class="home1" href="index.php">home</a></li>
           <span>></span>
           <a href="categories.php>id=<?php echo $get_product['0']['categories_id']?>"><?php echo $get_product['0']['categories']?></a>
        </div>
</div>
<hr style="margin-left:50px;width:1450px;">
<p style="margin-left:50px;width:1450px;background-color:ghostwhite;padding-left:50px;font-size:20px;">Buy Mobile</p>
<hr style="margin-left:50px;width:1450px;">
        <?php if(count($get_product)>0){?>
        <div class="rol" style="margin-left:50px;width:1250px;display:flex;flex-wrap:wrap;overflow:scroll;">
                <?php
                    foreach($get_product as $list){ 
                        ?>
                        <div class="newar"> 
                                <div class="category" style="height:381px;">
                                    <div>
                                        <a href="product.php?id=<?php echo $list['id']?>">
                                            <img src="<?php echo  PRODUCT_IMAGE_SITE_PATH.$list['image']?>">
                                        </a>
                                        
                                    </div>
                                    <div class="prodcutd">
                                    <h4><a  href="#"><?php echo 'Name:'.$list['name']?></a></h4>
                                    <ul class="price">
                                        <li class="oldp"><?php echo 'MRP:'.$list['mrp']?></li>
                                        <li><?php echo 'Price:'.$list['price']?></li>
                                    </ul>
                                    </div>
                                </div>
                        </div>
                 <?php } ?>
         </div> 
         <?php } else {
             echo "Data is not found.";
            }     ?>       
</body>
</html>